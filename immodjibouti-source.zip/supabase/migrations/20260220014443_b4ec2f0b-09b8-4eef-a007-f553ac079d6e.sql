
-- Drop restrictive policies
DROP POLICY IF EXISTS "Admin email can delete listings" ON public.listings;
DROP POLICY IF EXISTS "Admin email can insert listings" ON public.listings;
DROP POLICY IF EXISTS "Admin email can update listings" ON public.listings;
DROP POLICY IF EXISTS "Admin email can view all listings" ON public.listings;

-- Recreate as PERMISSIVE (default)
CREATE POLICY "Admin email full access select"
ON public.listings FOR SELECT
TO authenticated
USING ((auth.jwt() ->> 'email') = 'hhujmb8@gmail.com');

CREATE POLICY "Admin email full access insert"
ON public.listings FOR INSERT
TO authenticated
WITH CHECK ((auth.jwt() ->> 'email') = 'hhujmb8@gmail.com');

CREATE POLICY "Admin email full access update"
ON public.listings FOR UPDATE
TO authenticated
USING ((auth.jwt() ->> 'email') = 'hhujmb8@gmail.com');

CREATE POLICY "Admin email full access delete"
ON public.listings FOR DELETE
TO authenticated
USING ((auth.jwt() ->> 'email') = 'hhujmb8@gmail.com');

-- Public read via view for anonymous users
CREATE POLICY "Public read via anon"
ON public.listings FOR SELECT
TO anon
USING (true);
