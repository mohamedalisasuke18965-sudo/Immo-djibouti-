ALTER VIEW public.listings_public SET (security_invoker = off, security_barrier = on);
GRANT SELECT ON public.listings_public TO anon, authenticated;