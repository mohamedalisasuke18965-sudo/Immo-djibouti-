DROP POLICY IF EXISTS "Admin can read analytics" ON public.listing_analytics;

CREATE POLICY "Admin can read analytics"
ON public.listing_analytics
FOR SELECT
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));