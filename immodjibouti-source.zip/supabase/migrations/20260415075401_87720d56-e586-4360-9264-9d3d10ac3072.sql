
CREATE TABLE public.listing_analytics (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  listing_id UUID NOT NULL REFERENCES public.listings(id) ON DELETE CASCADE,
  action_type TEXT NOT NULL CHECK (action_type IN ('view', 'whatsapp', 'call')),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.listing_analytics ENABLE ROW LEVEL SECURITY;

-- Anyone (including anonymous) can insert analytics
CREATE POLICY "Anyone can insert analytics"
ON public.listing_analytics
FOR INSERT
TO anon, authenticated
WITH CHECK (true);

-- Only admin can read analytics
CREATE POLICY "Admin can read analytics"
ON public.listing_analytics
FOR SELECT
TO authenticated
USING ((auth.jwt() ->> 'email') = 'hhujmb8@gmail.com');
