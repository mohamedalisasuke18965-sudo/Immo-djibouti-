DO $$
DECLARE
  admin_user_id uuid;
BEGIN
  SELECT user_id INTO admin_user_id
  FROM public.user_roles
  WHERE role = 'admin'
  LIMIT 1;

  IF admin_user_id IS NULL THEN
    RAISE EXCEPTION 'Admin user id not found in public.user_roles';
  END IF;

  DROP POLICY IF EXISTS "Anyone can insert analytics" ON public.listing_analytics;
  DROP POLICY IF EXISTS "Non-admin users can insert analytics" ON public.listing_analytics;

  EXECUTE format(
    'CREATE POLICY "Non-admin users can insert analytics" ON public.listing_analytics FOR INSERT TO anon, authenticated WITH CHECK (auth.uid() IS NULL OR auth.uid() <> %L::uuid)',
    admin_user_id
  );
END $$;