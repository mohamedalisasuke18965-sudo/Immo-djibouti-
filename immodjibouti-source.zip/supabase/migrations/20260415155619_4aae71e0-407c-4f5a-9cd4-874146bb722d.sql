
-- 1. Remove broad anon SELECT on listings (exposes owner_contact)
DROP POLICY IF EXISTS "Public read via anon" ON public.listings;

-- 2. Ensure anon and authenticated can read the public view
GRANT SELECT ON public.listings_public TO anon, authenticated;

-- 3. Restrict storage upload to admin only
DROP POLICY IF EXISTS "Authenticated users can upload listing images" ON storage.objects;
CREATE POLICY "Admins can upload listing images"
  ON storage.objects FOR INSERT
  WITH CHECK (
    bucket_id = 'listing-images'
    AND public.has_role(auth.uid(), 'admin')
  );

-- 4. Restrict storage delete to admin only
DROP POLICY IF EXISTS "Authenticated users can delete listing images" ON storage.objects;
CREATE POLICY "Admins can delete listing images"
  ON storage.objects FOR DELETE
  USING (
    bucket_id = 'listing-images'
    AND public.has_role(auth.uid(), 'admin')
  );

-- 5. Fix analytics insert: require valid listing_id
DROP POLICY IF EXISTS "Non-admin users can insert analytics" ON public.listing_analytics;
CREATE POLICY "Non-admin users can insert analytics"
  ON public.listing_analytics FOR INSERT
  TO anon, authenticated
  WITH CHECK (
    ((auth.uid() IS NULL) OR (auth.uid() <> public.get_admin_user_id()))
    AND EXISTS (SELECT 1 FROM public.listings WHERE id = listing_id)
  );
