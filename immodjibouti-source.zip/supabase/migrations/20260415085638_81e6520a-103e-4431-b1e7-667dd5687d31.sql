DROP POLICY IF EXISTS "Non-admin users can insert analytics" ON public.listing_analytics;

CREATE POLICY "Non-admin users can insert analytics"
ON public.listing_analytics
FOR INSERT
TO anon, authenticated
WITH CHECK (
  auth.role() = 'anon'
  OR (
    auth.uid() IS NOT NULL
    AND auth.uid() <> (
      SELECT user_id
      FROM public.user_roles
      WHERE role = 'admin'
      LIMIT 1
    )
  )
);