
-- Drop existing restrictive policies
DROP POLICY IF EXISTS "Admins can delete listings" ON public.listings;
DROP POLICY IF EXISTS "Admins can insert listings" ON public.listings;
DROP POLICY IF EXISTS "Admins can update listings" ON public.listings;
DROP POLICY IF EXISTS "Admins can view all listings" ON public.listings;

-- Create permissive policies based on email
CREATE POLICY "Admin email can view all listings"
ON public.listings FOR SELECT
USING (auth.jwt() ->> 'email' = 'hhujmb8@gmail.com');

CREATE POLICY "Admin email can insert listings"
ON public.listings FOR INSERT
WITH CHECK (auth.jwt() ->> 'email' = 'hhujmb8@gmail.com');

CREATE POLICY "Admin email can update listings"
ON public.listings FOR UPDATE
USING (auth.jwt() ->> 'email' = 'hhujmb8@gmail.com');

CREATE POLICY "Admin email can delete listings"
ON public.listings FOR DELETE
USING (auth.jwt() ->> 'email' = 'hhujmb8@gmail.com');

-- Also keep public read access via the view
