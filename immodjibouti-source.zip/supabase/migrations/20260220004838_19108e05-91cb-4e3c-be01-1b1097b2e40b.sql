
-- Create a public view excluding owner_contact
CREATE VIEW public.listings_public
WITH (security_invoker = on) AS
SELECT id, title, price, description, quartier, image_url, created_at
FROM public.listings;

-- Drop the old permissive SELECT policy
DROP POLICY "Anyone can view listings" ON public.listings;

-- Only admins can SELECT from the base table (which includes owner_contact)
CREATE POLICY "Admins can view all listings"
  ON public.listings FOR SELECT
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

-- Grant SELECT on the view to anon and authenticated
GRANT SELECT ON public.listings_public TO anon, authenticated;
