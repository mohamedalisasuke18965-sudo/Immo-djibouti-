CREATE OR REPLACE FUNCTION public.get_admin_user_id()
RETURNS uuid
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT user_id
  FROM public.user_roles
  WHERE role = 'admin'
  ORDER BY user_id
  LIMIT 1
$$;

DROP POLICY IF EXISTS "Non-admin users can insert analytics" ON public.listing_analytics;

CREATE POLICY "Non-admin users can insert analytics"
ON public.listing_analytics
FOR INSERT
TO anon, authenticated
WITH CHECK (
  auth.uid() IS NULL
  OR auth.uid() <> public.get_admin_user_id()
);