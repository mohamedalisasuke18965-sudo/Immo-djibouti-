DROP VIEW IF EXISTS public.listings_public;
CREATE VIEW public.listings_public AS
SELECT id, title, price, description, quartier, image_url, owner_name, created_at
FROM public.listings;
ALTER VIEW public.listings_public SET (security_invoker = off, security_barrier = on);
GRANT SELECT ON public.listings_public TO anon, authenticated;