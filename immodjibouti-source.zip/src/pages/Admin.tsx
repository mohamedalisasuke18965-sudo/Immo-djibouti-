import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { AdminPanel } from "@/components/AdminPanel";
import { ListingCard } from "@/components/ListingCard";
import { Button } from "@/components/ui/button";
import { LogOut, ArrowLeft, Loader2, Eye, MessageCircle, Phone } from "lucide-react";
import logo from "@/assets/logo.png";
import type { Session } from "@supabase/supabase-js";
import type { Listing } from "@/lib/types";
import { listingSchema } from "@/lib/validation";

type AnalyticsCounts = Record<string, { view: number; whatsapp: number; call: number }>;

const ALLOWED_EMAIL = "hhujmb8@gmail.com";

const AdminPage = () => {
  const [session, setSession] = useState<Session | null>(null);
  const [authChecked, setAuthChecked] = useState(false);
  const [listings, setListings] = useState<Listing[]>([]);
  const [listingsLoading, setListingsLoading] = useState(true);
  const [isPublishing, setIsPublishing] = useState(false);
  const [analytics, setAnalytics] = useState<AnalyticsCounts>({});
  const navigate = useNavigate();

  // Listen for auth changes (handles navigate from login page)
  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, s) => {
      setSession(s);
      setAuthChecked(true);
    });
    // Also check current session once
    supabase.auth.getSession().then(({ data: { session: s } }) => {
      setSession(s);
      setAuthChecked(true);
    });
    return () => subscription.unsubscribe();
  }, []);

  const isAllowed = session?.user?.email === ALLOWED_EMAIL;

  const fetchListings = async () => {
    if (!isAllowed) return;
    setListingsLoading(true);
    const { data, error } = await supabase
      .from("listings" as any)
      .select("*")
      .order("created_at", { ascending: false });

    if (!error && data) {
      setListings(
        (data as any[]).map((row) => ({
          id: row.id,
          title: row.title,
          price: row.price,
          description: row.description || "",
          image: row.image_url || "",
          quartier: row.quartier,
          ownerContact: row.owner_contact,
          ownerName: row.owner_name || "",
          ownerFullName: row.owner_full_name || "",
          createdAt: new Date(row.created_at).getTime(),
        }))
      );
    }
    setListingsLoading(false);
  };

  const fetchAnalytics = async () => {
    const { data } = await supabase
      .from("listing_analytics")
      .select("listing_id, action_type");
    if (data) {
      const counts: AnalyticsCounts = {};
      (data as any[]).forEach((row) => {
        const id = row.listing_id;
        if (!counts[id]) counts[id] = { view: 0, whatsapp: 0, call: 0 };
        const t = row.action_type as "view" | "whatsapp" | "call";
        if (counts[id][t] !== undefined) counts[id][t]++;
      });
      setAnalytics(counts);
    }
  };

  useEffect(() => {
    if (isAllowed) {
      fetchListings();
      fetchAnalytics();
    }
  }, [isAllowed]);

  const addListing = async (listing: Omit<Listing, "id" | "createdAt">) => {
    const parsed = listingSchema.safeParse(listing);
    if (!parsed.success) return false;
    const v = parsed.data;
    const { error } = await supabase.from("listings" as any).insert({
      title: v.title, price: v.price, description: v.description,
      quartier: v.quartier, owner_contact: v.ownerContact, owner_name: v.ownerName, owner_full_name: v.ownerFullName, image_url: v.image,
    } as any);
    if (!error) {
      setIsPublishing(true);
      setTimeout(() => window.location.reload(), 2000);
    }
    return !error;
  };

  const deleteListing = async (id: string) => {
    const { error } = await supabase.from("listings" as any).delete().eq("id", id);
    if (!error) setListings((prev) => prev.filter((l) => l.id !== id));
  };

  // Show spinner only briefly while checking auth
  if (!authChecked) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center gap-3">
        <Loader2 className="h-10 w-10 animate-spin text-primary" />
        <p className="text-sm text-muted-foreground animate-pulse">Chargement du panneau admin…</p>
      </div>
    );
  }

  // Not logged in or wrong email → redirect to login
  if (!isAllowed) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center gap-4">
        <p className="text-destructive font-semibold">
          {session ? "Accès refusé" : "Veuillez vous connecter"}
        </p>
        <Button variant="outline" onClick={() => navigate("/se-connecter")}>Se connecter</Button>
      </div>
    );
  }

  return (
    <div className="min-h-screen relative">
      {isPublishing && (
        <div className="fixed inset-0 z-50 flex flex-col items-center justify-center gap-3 bg-background/70 backdrop-blur-sm">
          <Loader2 className="h-10 w-10 animate-spin text-primary" />
          <p className="text-sm font-medium text-foreground">Annonce publiée !</p>
          <p className="text-xs text-muted-foreground animate-pulse">Actualisation…</p>
        </div>
      )}
      <header className="sticky top-0 z-40 border-b bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/80">
        <div className="container flex h-14 items-center justify-between">
          <div className="flex items-center gap-2">
            <img src={logo} alt="ImmoDjibouti" className="h-8 w-8 rounded-md object-cover" />
            <h1 className="text-base font-bold tracking-tight text-foreground">
              Panneau <span className="text-primary">Admin</span>
            </h1>
          </div>
          <div className="flex items-center gap-1">
            <Button variant="ghost" size="sm" onClick={() => navigate("/")}>
              <ArrowLeft className="h-4 w-4 mr-1" />
              Accueil
            </Button>
            {session && (
              <Button variant="ghost" size="sm" onClick={async () => { await supabase.auth.signOut(); navigate("/"); }}>
                <LogOut className="h-4 w-4 mr-1" />
                Déconnexion
              </Button>
            )}
          </div>
        </div>
      </header>

      <main className="container py-4 space-y-6">
        <AdminPanel onAdd={addListing} />
        <h2 className="text-xl font-bold text-foreground">Annonces existantes</h2>
        {listingsLoading ? (
          <div className="flex justify-center py-10">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : listings.length === 0 ? (
          <p className="text-muted-foreground text-center py-10">Aucune annonce pour le moment</p>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {listings.map((listing) => {
              const stats = analytics[listing.id] || { view: 0, whatsapp: 0, call: 0 };
              return (
                <div key={listing.id} className="space-y-1.5">
                  <ListingCard listing={listing} isAdmin={true} onDelete={deleteListing} />
                  <div className="flex items-center justify-around rounded-md bg-muted/60 p-2 text-xs font-medium text-muted-foreground">
                    <span className="flex items-center gap-1"><Eye className="h-3.5 w-3.5" />{stats.view}</span>
                    <span className="flex items-center gap-1 text-green-600"><MessageCircle className="h-3.5 w-3.5" />{stats.whatsapp}</span>
                    <span className="flex items-center gap-1 text-primary"><Phone className="h-3.5 w-3.5" />{stats.call}</span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </main>
    </div>
  );
};

export default AdminPage;
