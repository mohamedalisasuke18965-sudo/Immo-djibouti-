import { Header } from "@/components/Header";
import { Phone, FileText, Search, Zap, CreditCard, Gauge } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const EddPage = () => {
  return (
    <div className="min-h-screen">
      <Header />

      <main className="container py-6 space-y-6">
        {/* Urgence */}
        <Card className="border-edd/30 bg-edd/5">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center gap-2 text-edd">
              <Phone className="h-5 w-5" />
              Urgence & Dépannage
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="text-sm text-foreground">
              Numéro unique pour tout Djibouti :{" "}
              <span className="font-bold text-edd">21 34 10 24</span>
            </p>
            <Button asChild className="w-full bg-edd hover:bg-edd/90 text-white">
              <a href="tel:21341024">📞 Appeler le dépannage EDD</a>
            </Button>
          </CardContent>
        </Card>

        {/* Types de Compteurs */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center gap-2">
              <Gauge className="h-5 w-5 text-edd" />
              Types de Compteurs à Djibouti
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="rounded-md border p-4 space-y-2">
              <p className="font-semibold text-foreground flex items-center gap-2">
                <Zap className="h-4 w-4 text-edd" /> Compteur Classique
              </p>
              <p className="text-sm text-muted-foreground">
                Boîtier gris/blanc avec cadran à aiguilles ou affichage mécanique. Relevé manuel par un agent EDD.
              </p>
            </div>
            <div className="rounded-md border p-4 space-y-2">
              <p className="font-semibold text-foreground flex items-center gap-2">
                <Zap className="h-4 w-4 text-edd" /> Compteur Intelligent
              </p>
              <p className="text-sm text-muted-foreground">
                Boîtier moderne avec écran digital avancé. Télé-relève automatique, pas besoin de passage d'agent.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Mutation */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center gap-2">
              <FileText className="h-5 w-5 text-edd" />
              Mutation (Changement de nom)
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="text-sm font-medium text-foreground">Documents requis :</p>
            <ul className="list-disc list-inside text-sm text-muted-foreground space-y-1.5 pl-1">
              <li>Carte Nationale d'Identité du nouveau titulaire</li>
              <li>Contrat de location ou Titre de propriété</li>
              <li>Dernière facture EDD du logement soldée (sans impayés)</li>
            </ul>
          </CardContent>
        </Card>

        {/* Paiement & Factures */}
        <Card className="border-edd/30">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center gap-2">
              <CreditCard className="h-5 w-5 text-edd" />
              Paiement & Factures
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="text-sm text-foreground font-medium">Moyens de paiement :</p>
            <p className="text-sm text-muted-foreground">
              D-money, Waafi (Cac Pay, Saba Pay, etc.)
            </p>
            <div className="rounded-md bg-edd/10 p-3">
              <p className="text-sm font-medium text-foreground flex items-center gap-2">
                <Search className="h-4 w-4 text-edd" />
                Vérifier les factures impayées
              </p>
              <p className="text-sm text-muted-foreground mt-1">
                Utilisez votre N° de contrat, N° de compteur ou N° de client.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Vérification des Impayés */}
        <Card className="border-edd/30 bg-edd/5">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center gap-2 text-edd">
              <Search className="h-5 w-5" />
              Vérification des Impayés
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="rounded-md border p-4 space-y-2">
              <p className="font-semibold text-foreground">Comment vérifier ?</p>
              <p className="text-sm text-muted-foreground">
                Un futur locataire ou acheteur peut vérifier si une maison a des dettes en utilisant soit le <span className="font-medium text-foreground">N° de contrat</span>, soit le <span className="font-medium text-foreground">N° de compteur</span>, soit le <span className="font-medium text-foreground">N° de client</span> (identifiants présents sur la facture).
              </p>
            </div>
            <div className="rounded-md border p-4 space-y-2">
              <p className="font-semibold text-foreground">Où vérifier ?</p>
              <p className="text-sm text-muted-foreground">
                Ces numéros permettent de consulter l'état du compte directement auprès de l'EDD ou via les services de paiement mobile pour confirmer que le logement est à jour.
              </p>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
};

export default EddPage;
