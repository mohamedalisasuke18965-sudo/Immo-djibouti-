import { Header } from "@/components/Header";
import { Phone, FileText, Search, Users, Globe } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const OneadPage = () => {
  return (
    <div className="min-h-screen">
      <Header />

      <main className="container py-6 space-y-6">
        {/* Section Urgence */}
        <Card className="border-primary/30 bg-primary/5">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center gap-2 text-primary">
              <Phone className="h-5 w-5" />
              Urgence Dépannage (Fuite/Coupure)
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="text-sm text-foreground">
              Numéro unique pour tous les quartiers de Djibouti :{" "}
              <span className="font-bold text-primary">21.34.04.98</span>
            </p>
            <Button asChild className="w-full">
              <a href="tel:21340498">📞 Appeler le dépannage</a>
            </Button>
          </CardContent>
        </Card>

        {/* Section Mutation */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center gap-2">
              <FileText className="h-5 w-5 text-primary" />
              Mutation (Changement de propriétaire)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="djiboutiens">
              <TabsList className="w-full">
                <TabsTrigger value="djiboutiens" className="flex-1 gap-1.5">
                  <Users className="h-4 w-4" />
                  Citoyens Djiboutiens
                </TabsTrigger>
                <TabsTrigger value="etrangers" className="flex-1 gap-1.5">
                  <Globe className="h-4 w-4" />
                  Étrangers
                </TabsTrigger>
              </TabsList>

              <TabsContent value="djiboutiens" className="mt-4 space-y-3">
                <p className="text-sm font-medium text-foreground">Documents requis :</p>
                <ul className="list-disc list-inside text-sm text-muted-foreground space-y-1.5 pl-1">
                  <li>Pièce d'identité</li>
                  <li>Titre foncier</li>
                  <li>Photo du compteur du jour</li>
                </ul>
                <div className="rounded-md bg-primary/10 p-3 text-center">
                  <p className="text-xs text-muted-foreground">Frais de mutation</p>
                  <p className="text-lg font-bold text-primary">11 500 FDJ</p>
                </div>
              </TabsContent>

              <TabsContent value="etrangers" className="mt-4 space-y-3">
                <p className="text-sm font-medium text-foreground">Documents requis :</p>
                <ul className="list-disc list-inside text-sm text-muted-foreground space-y-1.5 pl-1">
                  <li>Passeport</li>
                  <li>Contrat de bail</li>
                  <li>Photo du compteur du jour</li>
                </ul>
                <div className="rounded-md bg-primary/10 p-3 text-center">
                  <p className="text-xs text-muted-foreground">Frais de mutation</p>
                  <p className="text-lg font-bold text-primary">49 000 FDJ</p>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        {/* Section Vérification des Dettes */}
        <Card className="border-primary/30">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center gap-2">
              <Search className="h-5 w-5 text-primary" />
              Vérification des Dettes
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              Vous pouvez vérifier si une maison a des dettes au guichet avec le{" "}
              <span className="font-medium text-foreground">numéro de téléphone associé</span> ou les{" "}
              <span className="font-medium text-foreground">trois noms du titulaire</span>.
            </p>
          </CardContent>
        </Card>
      </main>
    </div>
  );
};

export default OneadPage;
