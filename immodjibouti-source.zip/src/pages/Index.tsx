import { useState, useMemo } from "react";
import { Link } from "react-router-dom";
import { Header } from "@/components/Header";
import { QuartierFilter } from "@/components/QuartierFilter";
import { ListingCard } from "@/components/ListingCard";
import { useListings } from "@/hooks/use-listings";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Home, Loader2, Droplets, Zap } from "lucide-react";
import type { Listing } from "@/lib/types";
const ADMIN_EMAIL = "hhujmb8@gmail.com";

const Index = () => {
  const { listings, loading } = useListings();
  const { isAdmin, session, loading: authLoading } = useAuth();
  const [selectedQuartier, setSelectedQuartier] = useState<string | null>(null);
  const viewerEmail = session?.user?.email ?? null;
  const trackingEnabled = !authLoading && viewerEmail !== ADMIN_EMAIL;

  // Extract unique quartiers from actual listings
  const quartiers = useMemo(() => {
    const set = new Set(listings.map((l) => l.quartier));
    return Array.from(set).sort();
  }, [listings]);

  const filtered = selectedQuartier
    ? listings.filter((l) => l.quartier === selectedQuartier)
    : listings;

  return (
    <div className="min-h-screen">
      <Header />

      <main className="container py-6 space-y-6">
        <div className="grid grid-cols-2 gap-3">
          <Button asChild size="lg" className="text-base py-6">
            <Link to="/onead">
              <Droplets className="h-5 w-5 mr-2" />
              ONEAD (Eau)
            </Link>
          </Button>
          <Button asChild size="lg" className="text-base py-6 bg-edd hover:bg-edd/90">
            <Link to="/edd">
              <Zap className="h-5 w-5 mr-2" />
              EDD (Électricité)
            </Link>
          </Button>
        </div>

        <QuartierFilter
          quartiers={quartiers}
          selected={selectedQuartier}
          onSelect={setSelectedQuartier}
        />

        {loading ? (
          <div className="flex justify-center py-20">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-center text-muted-foreground">
            <Home className="h-12 w-12 mb-4 opacity-40" />
            <p className="text-lg font-medium">Aucune annonce disponible</p>
            <p className="text-sm mt-1">
              {selectedQuartier
                ? `Pas d'annonce à ${selectedQuartier} pour le moment`
                : "Les annonces apparaîtront ici"}
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            {filtered.map((listing) => (
              <ListingCard
                key={listing.id}
                listing={listing}
                isAdmin={isAdmin}
                trackingEnabled={trackingEnabled}
                viewerEmail={viewerEmail}
              />
            ))}
          </div>
        )}
      </main>

    </div>
  );
};

export default Index;
