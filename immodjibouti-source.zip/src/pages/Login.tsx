import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Lock, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

const LoginPage = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const FAIL_KEY = "logo_fail_count";
  const BLOCK_KEY = "logo_block_until";
  const MAX_FAILS = 3;
  const BLOCK_MS = 5 * 60 * 60 * 1000; // 5 heures

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Vérifier si déjà bloqué
    const blockUntil = parseInt(localStorage.getItem(BLOCK_KEY) || "0", 10);
    if (blockUntil && Date.now() < blockUntil) {
      setError("Nombre d'essais maximum atteint. Le logo est désactivé pour 5h.");
      return;
    }

    setError("");
    setLoading(true);

    const { data, error: authError } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (authError) {
      const fails = parseInt(localStorage.getItem(FAIL_KEY) || "0", 10) + 1;
      localStorage.setItem(FAIL_KEY, String(fails));

      if (fails >= MAX_FAILS) {
        const until = Date.now() + BLOCK_MS;
        localStorage.setItem(BLOCK_KEY, String(until));
        localStorage.removeItem(FAIL_KEY);
        alert("Nombre d'essais maximum atteint. Le logo est désactivé pour 5h.");
        setError("Logo désactivé pour 5h.");
        setLoading(false);
        setTimeout(() => { window.location.href = "/"; }, 1500);
        return;
      }

      setError(`Email ou mot de passe incorrect (${fails}/${MAX_FAILS})`);
      setLoading(false);
      return;
    }

    // Connexion réussie : reset les compteurs
    localStorage.removeItem(FAIL_KEY);
    localStorage.removeItem(BLOCK_KEY);

    // Check if user is admin
    const { data: roleData } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", data.user.id)
      .eq("role", "admin")
      .maybeSingle();

    if (roleData) {
      window.location.href = "/admin";
    } else {
      window.location.href = "/";
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <Card className="w-full max-w-sm animate-fade-in shadow-lg border-primary/20">
        <CardHeader className="text-center">
          <div className="mx-auto mb-3 h-14 w-14 rounded-full bg-primary/10 flex items-center justify-center">
            <Lock className="h-7 w-7 text-primary" />
          </div>
          <CardTitle className="text-xl">Espace Connexion</CardTitle>
          <p className="text-sm text-muted-foreground mt-1">
            Connectez-vous à votre compte ImmoDjibouti
          </p>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="votre@email.com"
                required
                autoFocus
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Mot de passe</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                required
              />
            </div>
            {error && <p className="text-sm text-destructive text-center">{error}</p>}
            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <Lock className="h-4 w-4 mr-2" />
              )}
              {loading ? "Connexion en cours..." : "Se connecter"}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default LoginPage;
