import { createRoot } from "react-dom/client";
import App from "./App.tsx";
import "./index.css";

createRoot(document.getElementById("root")!).render(<App />);

// Service Worker — production seulement, jamais dans la preview Lovable / iframe
if ("serviceWorker" in navigator) {
  const isInIframe = (() => {
    try {
      return window.self !== window.top;
    } catch {
      return true;
    }
  })();

  const host = window.location.hostname;
  const isPreviewHost =
    host.includes("lovableproject.com") ||
    host.includes("lovable.app") && host.includes("id-preview--") ||
    host === "localhost" ||
    host === "127.0.0.1";

  if (isInIframe || isPreviewHost) {
    // Désinscrire tout SW existant en preview pour éviter le cache bloquant
    navigator.serviceWorker.getRegistrations().then((regs) => {
      regs.forEach((r) => r.unregister());
    });
  } else {
    window.addEventListener("load", () => {
      navigator.serviceWorker.register("/sw.js").catch(() => {});
    });
  }
}

// Supprimer le badge "Edit with Lovable" du DOM (production uniquement)
(() => {
  const host = window.location.hostname;
  const isPreview =
    host.includes("lovableproject.com") ||
    (host.includes("lovable.app") && host.includes("id-preview--")) ||
    host === "localhost" ||
    host === "127.0.0.1";
  if (isPreview) return;

  const removeBadge = () => {
    document
      .querySelectorAll(
        '[class*="lovable"], [id*="lovable"], iframe[src*="lovable"], a[href*="lovable.dev"]'
      )
      .forEach((el) => el.remove());
  };

  removeBadge();
  const observer = new MutationObserver(removeBadge);
  observer.observe(document.documentElement, { childList: true, subtree: true });
})();
