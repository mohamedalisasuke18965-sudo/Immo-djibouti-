/**
 * Formate un prix en FDJ avec séparateur de milliers (point).
 * Accepte une chaîne ou un nombre. Si la valeur ne contient aucun chiffre,
 * la chaîne d'origine est renvoyée telle quelle (avec le suffixe FDJ).
 */
export function formatPriceFDJ(value: string | number | null | undefined): string {
  if (value === null || value === undefined || value === "") return "";
  const raw = String(value).trim();

  // Si la chaîne contient déjà "FDJ", on l'enlève pour reformater proprement
  const cleaned = raw.replace(/fdj/gi, "").trim();

  // Extraire uniquement les chiffres
  const digits = cleaned.replace(/[^\d]/g, "");

  if (!digits) {
    // Aucun chiffre détecté : on renvoie la valeur d'origine + FDJ
    return `${cleaned} FDJ`.trim();
  }

  const number = parseInt(digits, 10);
  const formatted = number.toLocaleString("fr-FR").replace(/\s/g, ".");
  return `${formatted} FDJ`;
}

/** Garde uniquement les chiffres saisis dans un input prix. */
export function sanitizePriceInput(value: string): string {
  return value.replace(/[^\d]/g, "");
}
