export interface Listing {
  id: string;
  title: string;
  price: string;
  description: string;
  image: string;
  quartier: string;
  ownerContact: string; // private - admin only
  ownerName: string; // public agency/advertiser name shown on card
  ownerFullName: string; // private - admin only, real owner name
  createdAt: number;
}

export const AGENT_PHONE = "+25377193334";
export const AGENT_PHONE_DISPLAY = "+253 77 19 33 34";
