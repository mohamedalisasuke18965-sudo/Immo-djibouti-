import { z } from "zod";

export const listingSchema = z.object({
  title: z.string().trim().min(1, "Le titre est requis").max(200, "Le titre ne doit pas dépasser 200 caractères"),
  price: z.string().trim().min(1, "Le prix est requis").max(50, "Le prix ne doit pas dépasser 50 caractères"),
  description: z.string().max(2000, "La description ne doit pas dépasser 2000 caractères").default(""),
  quartier: z.string().trim().min(1, "Le quartier est requis").max(100, "Le quartier ne doit pas dépasser 100 caractères"),
  ownerContact: z.string().trim().min(1, "Le contact est requis").max(50, "Le contact ne doit pas dépasser 50 caractères"),
  ownerName: z.string().trim().max(100, "Le nom ne doit pas dépasser 100 caractères").default(""),
  ownerFullName: z.string().trim().max(100, "Le nom du propriétaire ne doit pas dépasser 100 caractères").default(""),
  image: z.string().max(5000).default(""),
});

export type ListingInput = z.infer<typeof listingSchema>;
