import { useState, useEffect, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { Listing } from "@/lib/types";
import { listingSchema } from "@/lib/validation";

export function useListings(isAdmin = false) {
  const [listings, setListings] = useState<Listing[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchListings = useCallback(async () => {
    setLoading(true);

    if (isAdmin) {
      // Admin: query full listings table (includes owner_contact)
      const { data, error } = await supabase
        .from("listings" as any)
        .select("*")
        .order("created_at", { ascending: false });

      if (!error && data) {
        const fetched = (data as any[]).map((row) => ({
          id: row.id,
          title: row.title,
          price: row.price,
          description: row.description || "",
          image: row.image_url || "",
          quartier: row.quartier,
          ownerContact: row.owner_contact,
          ownerName: row.owner_name || "",
          ownerFullName: row.owner_full_name || "",
          createdAt: new Date(row.created_at).getTime(),
        }));
        setListings(fetched);
      } else {
        setListings([]);
      }
    } else {
      // Public: query view without owner_contact
      const { data, error } = await supabase
        .from("listings_public" as any)
        .select("*")
        .order("created_at", { ascending: false });

      if (!error && data) {
        const fetched = (data as any[]).map((row) => ({
          id: row.id,
          title: row.title,
          price: row.price,
          description: row.description || "",
          image: row.image_url || "",
          quartier: row.quartier,
          ownerContact: "",
          ownerName: row.owner_name || "",
          ownerFullName: "",
          createdAt: new Date(row.created_at).getTime(),
        }));
        setListings(fetched);
      } else {
        setListings([]);
      }
    }

    setLoading(false);
  }, [isAdmin]);

  useEffect(() => {
    fetchListings();
  }, [fetchListings]);

  const addListing = async (listing: Omit<Listing, "id" | "createdAt">) => {
    const parsed = listingSchema.safeParse(listing);
    if (!parsed.success) {
      console.error("Validation error:", parsed.error.flatten());
      return false;
    }

    const validated = parsed.data;
    const { error } = await supabase.from("listings" as any).insert({
      title: validated.title,
      price: validated.price,
      description: validated.description,
      quartier: validated.quartier,
      owner_contact: validated.ownerContact,
      owner_name: validated.ownerName,
      owner_full_name: validated.ownerFullName,
      image_url: validated.image,
    } as any);

    if (!error) {
      await fetchListings();
    }
    return !error;
  };

  const deleteListing = async (id: string) => {
    const { error } = await supabase
      .from("listings" as any)
      .delete()
      .eq("id", id);

    if (!error) {
      setListings((prev) => prev.filter((l) => l.id !== id));
    }
  };

  const updateListing = async (
    id: string,
    data: Partial<Omit<Listing, "id" | "createdAt">>
  ) => {
    const partialSchema = listingSchema.partial();
    const parsed = partialSchema.safeParse(data);
    if (!parsed.success) {
      console.error("Validation error:", parsed.error.flatten());
      return;
    }

    const validated = parsed.data;
    const dbData: any = {};
    if (validated.title !== undefined) dbData.title = validated.title;
    if (validated.price !== undefined) dbData.price = validated.price;
    if (validated.description !== undefined) dbData.description = validated.description;
    if (validated.quartier !== undefined) dbData.quartier = validated.quartier;
    if (validated.ownerContact !== undefined) dbData.owner_contact = validated.ownerContact;
    if (validated.ownerName !== undefined) dbData.owner_name = validated.ownerName;
    if (validated.image !== undefined) dbData.image_url = validated.image;

    const { error } = await supabase
      .from("listings" as any)
      .update(dbData)
      .eq("id", id);

    if (!error) {
      await fetchListings();
    }
  };

  return { listings, loading, addListing, deleteListing, updateListing };
}
