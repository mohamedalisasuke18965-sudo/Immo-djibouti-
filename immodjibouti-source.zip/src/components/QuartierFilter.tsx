import { Badge } from "@/components/ui/badge";

interface QuartierFilterProps {
  quartiers: string[];
  selected: string | null;
  onSelect: (q: string | null) => void;
}

export function QuartierFilter({ quartiers, selected, onSelect }: QuartierFilterProps) {
  if (quartiers.length === 0) return null;

  return (
    <div className="flex flex-wrap gap-2 py-4">
      <Badge
        className={`cursor-pointer text-sm px-3 py-1.5 ${
          selected === null
            ? "bg-primary text-primary-foreground"
            : "bg-muted text-muted-foreground hover:bg-muted/80"
        }`}
        onClick={() => onSelect(null)}
      >
        Tous
      </Badge>
      {quartiers.map((q) => (
        <Badge
          key={q}
          className={`cursor-pointer text-sm px-3 py-1.5 ${
            selected === q
              ? "bg-primary text-primary-foreground"
              : "bg-muted text-muted-foreground hover:bg-muted/80"
          }`}
          onClick={() => onSelect(q)}
        >
          {q}
        </Badge>
      ))}
    </div>
  );
}
