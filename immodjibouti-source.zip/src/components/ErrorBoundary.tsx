import { Component, type ReactNode } from "react";
import { Button } from "@/components/ui/button";

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex flex-col items-center justify-center gap-4 p-4 bg-background">
          <h1 className="text-xl font-bold text-destructive">Une erreur est survenue</h1>
          <p className="text-sm text-muted-foreground text-center max-w-md">
            {this.state.error?.message || "Erreur inattendue"}
          </p>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => this.setState({ hasError: false, error: null })}>
              Réessayer
            </Button>
            <Button variant="outline" onClick={() => window.location.href = "/"}>
              Accueil
            </Button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
