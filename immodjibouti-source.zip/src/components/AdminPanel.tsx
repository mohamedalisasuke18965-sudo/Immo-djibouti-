import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus, ImagePlus, Loader2 } from "lucide-react";
import type { Listing } from "@/lib/types";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import { formatPriceFDJ, sanitizePriceInput } from "@/lib/format";

interface AdminPanelProps {
  onAdd: (listing: Omit<Listing, "id" | "createdAt">) => Promise<boolean>;
}

export function AdminPanel({ onAdd }: AdminPanelProps) {
  const [price, setPrice] = useState("");
  const [quartier, setQuartier] = useState("");
  const [rooms, setRooms] = useState("");
  const [ownerContact, setOwnerContact] = useState("");
  const [ownerName, setOwnerName] = useState("");
  const [ownerFullName, setOwnerFullName] = useState("");
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setImageFile(file);
    const reader = new FileReader();
    reader.onload = () => setImagePreview(reader.result as string);
    reader.readAsDataURL(file);
  };

  const uploadImage = async (file: File): Promise<string> => {
    const ext = file.name.split(".").pop();
    const fileName = `${crypto.randomUUID()}.${ext}`;
    const { error } = await supabase.storage
      .from("listing-images")
      .upload(fileName, file);
    if (error) throw error;
    const { data } = supabase.storage
      .from("listing-images")
      .getPublicUrl(fileName);
    return data.publicUrl;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!price || !quartier || !ownerContact) return;

    setSubmitting(true);
    try {
      let imageUrl = "";
      if (imageFile) {
        imageUrl = await uploadImage(imageFile);
      }

      const title = rooms ? `Appartement F${rooms}` : quartier;

      const success = await onAdd({
        title,
        price,
        description: "",
        quartier: quartier,
        ownerContact,
        ownerName,
        ownerFullName,
        image: imageUrl,
      });

      if (success) {
        setPrice("");
        setQuartier("");
        setRooms("");
        setOwnerContact("");
        setOwnerName("");
        setOwnerFullName("");
        setImageFile(null);
        setImagePreview("");
        toast({ title: "Annonce publiée !" });
      }
    } catch {
      toast({ title: "Erreur", description: "Impossible de publier l'annonce", variant: "destructive" });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Card className="border-border/50">
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center gap-2 text-foreground text-lg">
          <Plus className="h-5 w-5" />
          Ajouter une annonce
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Photo upload zone */}
          <div className="space-y-2">
            <Label className="font-semibold">Photo</Label>
            <button
              type="button"
              onClick={() => document.getElementById("image-input")?.click()}
              className="w-full border-2 border-dashed border-muted-foreground/30 rounded-lg p-8 flex flex-col items-center justify-center gap-2 hover:border-primary/50 transition-colors"
            >
              {imagePreview ? (
                <img src={imagePreview} alt="Preview" className="max-h-40 rounded-lg object-cover" />
              ) : (
                <>
                  <ImagePlus className="h-10 w-10 text-muted-foreground/50" />
                  <span className="text-sm text-primary">Cliquez pour choisir une photo</span>
                </>
              )}
            </button>
            <input id="image-input" type="file" accept="image/*" className="hidden" onChange={handleImageUpload} />
          </div>

          {/* Quartier — saisie libre */}
          <div className="space-y-2">
            <Label className="font-semibold">Quartier</Label>
            <Input
              value={quartier}
              onChange={(e) => setQuartier(e.target.value)}
              placeholder="Ex: Balbala, Gabode, Haramous..."
              required
            />
          </div>

          {/* Prix */}
          <div className="space-y-2">
            <Label className="font-semibold">Prix (FDJ)</Label>
            <div className="relative">
              <Input
                value={price}
                onChange={(e) => setPrice(sanitizePriceInput(e.target.value))}
                placeholder="Ex: 50000"
                inputMode="numeric"
                pattern="[0-9]*"
                className="pr-14"
                required
              />
              <span className="absolute right-3 top-1/2 -translate-y-1/2 text-sm font-semibold text-muted-foreground pointer-events-none">
                FDJ
              </span>
            </div>
            {price && (
              <p className="text-xs text-muted-foreground">
                Aperçu : <span className="font-semibold text-foreground">{formatPriceFDJ(price)}</span>
              </p>
            )}
          </div>

          {/* Nombre de chambres */}
          <div className="space-y-2">
            <Label className="font-semibold">Nombre total de pièces (F)</Label>
            <Input
              value={rooms}
              onChange={(e) => setRooms(e.target.value)}
              placeholder="Ex: 3 (pour Appartement F3)"
            />
          </div>

          {/* Nom de l'agence ou de l'annonceur */}
          <div className="space-y-2">
            <Label className="font-semibold">Nom de l'agence ou de l'annonceur</Label>
            <Input
              value={ownerName}
              onChange={(e) => setOwnerName(e.target.value)}
              placeholder="Laissez vide si particulier"
            />
          </div>

          {/* Nom du propriétaire (privé - admin uniquement) */}
          <div className="space-y-2">
            <Label className="font-semibold">Nom du propriétaire (privé)</Label>
            <Input
              value={ownerFullName}
              onChange={(e) => setOwnerFullName(e.target.value)}
              placeholder="Nom complet du propriétaire"
            />
            <p className="text-xs text-muted-foreground">
              Visible uniquement par l'administrateur. Jamais affiché sur l'annonce.
            </p>
          </div>

          {/* Téléphone */}
          <div className="space-y-2">
            <Label className="font-semibold text-destructive">Téléphone</Label>
            <Input
              value={ownerContact}
              onChange={(e) => setOwnerContact(e.target.value)}
              placeholder="Ex: +253 77 00 00 00"
              required
            />
          </div>

          <Button type="submit" className="w-full" size="lg" disabled={submitting}>
            {submitting ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : <Plus className="h-4 w-4 mr-1" />}
            {submitting ? "Publication..." : "Publier l'annonce"}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
