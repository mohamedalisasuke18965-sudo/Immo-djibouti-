import { Phone, MessageCircle, Trash2, Eye, User, Building2 } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import type { Listing } from "@/lib/types";
import { AGENT_PHONE, AGENT_PHONE_DISPLAY } from "@/lib/types";
import { supabase } from "@/integrations/supabase/client";
import { formatPriceFDJ } from "@/lib/format";

const ADMIN_EMAIL = "hhujmb8@gmail.com";

const trackAction = async (listingId: string, actionType: "view" | "whatsapp" | "call") => {
  try {
    await supabase.from("listing_analytics").insert({ listing_id: listingId, action_type: actionType });
  } catch (e) {
    // silent fail – don't block user interaction
  }
};

interface ListingCardProps {
  listing: Listing;
  isAdmin: boolean;
  trackingEnabled?: boolean;
  viewerEmail?: string | null;
  onDelete?: (id: string) => void;
}

export function ListingCard({ listing, isAdmin, trackingEnabled = !isAdmin, viewerEmail, onDelete }: ListingCardProps) {
  const currentUserEmail = viewerEmail ?? null;

  const trackOnce = (listingId: string, actionType: "view" | "whatsapp" | "call") => {
    if (!trackingEnabled) return;
    if (isAdmin) return;
    if (currentUserEmail === ADMIN_EMAIL) return;
    const key = `tracked_${actionType}_${listingId}`;
    if (sessionStorage.getItem(key)) return;
    sessionStorage.setItem(key, "1");
    trackAction(listingId, actionType);
  };

  const trackClickWithView = (listingId: string, actionType: "whatsapp" | "call") => {
    trackOnce(listingId, "view"); // auto-view (skipped if already tracked)
    trackOnce(listingId, actionType);
  };

  const whatsappMessage = encodeURIComponent(
    `Bonjour, je suis intéressé par la maison à ${listing.quartier} : ${listing.title}`
  );
  const whatsappUrl = `https://wa.me/${AGENT_PHONE}?text=${whatsappMessage}`;
  const callUrl = `tel:${AGENT_PHONE}`;

  return (
    <Card className="overflow-hidden hover-scale animate-fade-in">
      {listing.image && (
        <div className="aspect-square overflow-hidden">
          <img
            src={listing.image}
            alt={listing.title}
            className="h-full w-full object-cover"
            loading="lazy"
          />
        </div>
      )}
      <CardContent className="p-2.5 space-y-1.5">
        <div className="flex items-start justify-between gap-1">
          <h3 className="font-semibold text-foreground text-xs line-clamp-2 leading-tight">{listing.title}</h3>
          <Badge className="shrink-0 bg-secondary text-secondary-foreground text-[9px] px-1 py-0">
            {listing.quartier}
          </Badge>
        </div>

        <p className="text-base font-extrabold text-primary">{formatPriceFDJ(listing.price)}</p>

        {listing.description && (
          <p className="text-[10px] text-muted-foreground line-clamp-2 leading-tight">{listing.description}</p>
        )}


        {(() => {
          const displayedName = listing.ownerName?.trim() ? listing.ownerName.trim() : "Particulier";
          const isParticulier = displayedName === "Particulier";
          return (
            <div className="rounded-md bg-red-600 p-1.5 text-xs">
              <div className="flex items-center gap-1 text-white font-semibold">
                {isParticulier ? (
                  <User className="h-3.5 w-3.5 text-white" />
                ) : (
                  <Building2 className="h-3.5 w-3.5 text-white" />
                )}
                {displayedName}
              </div>
            </div>
          );
        })()}

        {isAdmin && (
          <div className="rounded-md bg-accent/50 p-1.5 text-xs space-y-0.5">
            {listing.ownerFullName && (
              <div className="flex items-center gap-1 text-accent-foreground font-medium">
                <User className="h-3 w-3" />
                Propriétaire : {listing.ownerFullName}
              </div>
            )}
            <div className="flex items-center gap-1 text-accent-foreground font-medium">
              <Phone className="h-3 w-3" />
              Contact : {listing.ownerContact}
            </div>
          </div>
        )}

        <div className="flex gap-2 pt-0.5" onClick={(e) => e.stopPropagation()}>
          <Button
            className="flex-1 bg-whatsapp text-whatsapp-foreground hover:bg-whatsapp/90 h-9 w-9 p-0"
            size="icon"
            onClick={() => {
              trackClickWithView(listing.id, "whatsapp");
              window.open(whatsappUrl, "_blank", "noopener,noreferrer");
            }}
          >
            <MessageCircle className="h-4 w-4" />
          </Button>
          <Button
            variant="outline"
            size="icon"
            className="flex-1 h-9 w-9 p-0"
            onClick={() => {
              trackClickWithView(listing.id, "call");
              window.location.href = callUrl;
            }}
          >
            <Phone className="h-4 w-4" />
          </Button>
        </div>

        {isAdmin && onDelete && (
          <Button
            variant="destructive"
            size="sm"
            className="w-full text-xs h-7"
            onClick={() => onDelete(listing.id)}
          >
            <Trash2 className="h-3.5 w-3.5 mr-1" />
            Supprimer
          </Button>
        )}
      </CardContent>
    </Card>
  );
}
