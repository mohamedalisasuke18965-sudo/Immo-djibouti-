import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MessageCircle, Phone } from "lucide-react";
import type { Listing } from "@/lib/types";
import { AGENT_PHONE } from "@/lib/types";
import { formatPriceFDJ } from "@/lib/format";

interface ListingDetailDialogProps {
  listing: Listing | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function ListingDetailDialog({ listing, open, onOpenChange }: ListingDetailDialogProps) {
  if (!listing) return null;

  const whatsappMessage = encodeURIComponent(
    `Bonjour, je suis intéressé par la maison à ${listing.quartier} : ${listing.title}`
  );
  const whatsappUrl = `https://wa.me/${AGENT_PHONE}?text=${whatsappMessage}`;
  const callUrl = `tel:${AGENT_PHONE}`;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto p-0">
        {listing.image && (
          <img
            src={listing.image}
            alt={listing.title}
            className="w-full aspect-[4/3] object-cover rounded-t-lg"
          />
        )}
        <div className="p-4 space-y-3">
          <DialogHeader className="space-y-1">
            <div className="flex items-start justify-between gap-2">
              <DialogTitle className="text-lg leading-tight">{listing.title}</DialogTitle>
              <Badge className="shrink-0 bg-secondary text-secondary-foreground text-xs">
                {listing.quartier}
              </Badge>
            </div>
            <DialogDescription className="sr-only">Détails de l'annonce</DialogDescription>
          </DialogHeader>

          <p className="text-2xl font-extrabold text-primary">{formatPriceFDJ(listing.price)}</p>

          {listing.description && (
            <p className="text-sm text-muted-foreground whitespace-pre-line">{listing.description}</p>
          )}

          <div className="flex gap-2 pt-2">
            <Button
              className="flex-1 bg-whatsapp text-whatsapp-foreground hover:bg-whatsapp/90"
              onClick={() => window.open(whatsappUrl, "_blank", "noopener,noreferrer")}
            >
              <MessageCircle className="h-4 w-4 mr-2" />
              WhatsApp
            </Button>
            <Button
              variant="outline"
              className="flex-1"
              onClick={() => { window.location.href = callUrl; }}
            >
              <Phone className="h-4 w-4 mr-2" />
              Appeler
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
