import { useEffect, useState } from "react";
import { WifiOff } from "lucide-react";

export const OfflineBanner = () => {
  const [offline, setOffline] = useState(
    typeof navigator !== "undefined" ? !navigator.onLine : false
  );

  useEffect(() => {
    const on = () => setOffline(false);
    const off = () => setOffline(true);
    window.addEventListener("online", on);
    window.addEventListener("offline", off);
    return () => {
      window.removeEventListener("online", on);
      window.removeEventListener("offline", off);
    };
  }, []);

  if (!offline) return null;

  return (
    <div className="fixed bottom-3 left-1/2 -translate-x-1/2 z-50 bg-foreground/90 text-background text-xs px-3 py-1.5 rounded-full shadow-lg flex items-center gap-2 backdrop-blur">
      <WifiOff className="h-3.5 w-3.5" />
      <span>Mode hors-ligne actif</span>
    </div>
  );
};
