import { useEffect, useRef } from "react";
import { Droplets, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import logo from "@/assets/logo.png";

export function Header() {
  const logoRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = logoRef.current;
    if (!el) return;

    const BLOCK_KEY = "logo_block_until";
    const isBlocked = () => {
      const until = parseInt(localStorage.getItem(BLOCK_KEY) || "0", 10);
      if (until && Date.now() < until) return true;
      if (until && Date.now() >= until) localStorage.removeItem(BLOCK_KEY);
      return false;
    };

    let count = 0;
    let timer: ReturnType<typeof setTimeout> | null = null;

    const handler = (e: Event) => {
      // Si bloqué après 3 échecs : logo totalement incliquable
      if (isBlocked()) return;

      e.preventDefault();
      e.stopPropagation();
      count += 1;

      if (timer) clearTimeout(timer);

      if (count >= 3) {
        count = 0;
        window.location.assign("/login");
        return;
      }

      timer = setTimeout(() => {
        count = 0;
      }, 2000);
    };

    el.addEventListener("click", handler, true);
    return () => {
      el.removeEventListener("click", handler, true);
      if (timer) clearTimeout(timer);
    };
  }, []);

  return (
    <header className="sticky top-0 z-40 border-b bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/80">
      <div className="container flex h-16 items-center justify-between">
        <div
          ref={logoRef}
          className="flex items-center gap-2 select-none cursor-pointer"
          role="button"
          tabIndex={0}
        >
          <img src={logo} alt="ImmoDjibouti" className="h-9 w-9 rounded-md object-cover pointer-events-none" />
          <h1 className="text-lg font-bold tracking-tight text-foreground pointer-events-none">
            Immo<span className="text-secondary">Dji</span><span className="text-primary">bouti</span>
          </h1>
        </div>
        <div className="flex items-center gap-0.5">
          <Button variant="ghost" size="sm" className="h-8 px-2 text-xs" asChild>
            <Link to="/onead">
              <Droplets className="mr-0.5 h-3.5 w-3.5" />
              ONEAD
            </Link>
          </Button>
          <Button variant="ghost" size="sm" className="h-8 px-2 text-xs" asChild>
            <Link to="/edd">
              <Zap className="mr-0.5 h-3.5 w-3.5" />
              EDD
            </Link>
          </Button>
        </div>
      </div>
    </header>
  );
}
