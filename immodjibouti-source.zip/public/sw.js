// ImmoDjibouti Service Worker v16
const CACHE_VERSION = "immodjibouti-v16";
const STATIC_CACHE = `${CACHE_VERSION}-static`;
const RUNTIME_CACHE = `${CACHE_VERSION}-runtime`;

const PRECACHE_URLS = [
  "/",
  "/manifest.json?v=15",
  "/favicon.ico",
  "/favicon.png",
  "/logo.png",
  "/apple-touch-icon.png?v=15",
  "/icon-72x72.png?v=15",
  "/icon-96x96.png?v=15",
  "/icon-128x128.png?v=15",
  "/icon-144x144.png?v=15",
  "/icon-152x152.png?v=15",
  "/icon-180x180.png?v=15",
  "/icon-192x192.png?v=15",
  "/icon-384x384.png?v=15",
  "/icon-512x512.png?v=15",
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(STATIC_CACHE).then((cache) =>
      Promise.all(
        PRECACHE_URLS.map((url) =>
          cache.add(url).catch(() => {/* ignore */})
        )
      )
    ).then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys
          .filter((k) => !k.startsWith(CACHE_VERSION))
          .map((k) => caches.delete(k))
      )
    ).then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;

  const url = new URL(req.url);

  // Ne pas mettre en cache Supabase / API
  if (url.hostname.includes("supabase.co") || url.hostname.includes("supabase.in")) {
    return;
  }

  // Navigation: network-first, fallback cache, fallback /
  if (req.mode === "navigate") {
    event.respondWith(
      fetch(req)
        .then((res) => {
          const copy = res.clone();
          caches.open(RUNTIME_CACHE).then((c) => c.put(req, copy));
          return res;
        })
        .catch(() =>
          caches.match(req).then((r) => r || caches.match("/"))
        )
    );
    return;
  }

  // Assets / fonts / images: cache-first
  if (
    url.origin === self.location.origin ||
    /\.(png|jpg|jpeg|svg|webp|ico|woff2?|ttf|otf|css|js)$/i.test(url.pathname) ||
    url.hostname.includes("fonts.googleapis.com") ||
    url.hostname.includes("fonts.gstatic.com")
  ) {
    event.respondWith(
      caches.match(req).then((cached) => {
        if (cached) return cached;
        return fetch(req)
          .then((res) => {
            if (res && res.status === 200) {
              const copy = res.clone();
              caches.open(RUNTIME_CACHE).then((c) => c.put(req, copy));
            }
            return res;
          })
          .catch(() => cached);
      })
    );
  }
});
